package Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import Bean.Noticia;
import ConnectionFactory.ConnectionFactory;

public class NoticiaDao {

	private Connection conect;

	public NoticiaDao(){
		new ConnectionFactory();
		this.conect = ConnectionFactory.conectar();
	}

	public void insertNoticia(Noticia noticia) {

		String insert = "INSERT INTO noticia (descricao,titulo,texto) " + "VALUES (?,?,?)";

		try (PreparedStatement preparedStatement = conect.prepareStatement(insert);) {

			preparedStatement.setString(1, noticia.getDescricao());
			preparedStatement.setString(2, noticia.getTitulo());
			preparedStatement.setString(3, noticia.getTexto());
			preparedStatement.execute();
		} catch (Exception e) {
			e.printStackTrace();
			try {
				conect.rollback();
			} catch (SQLException ex) {
				System.out.println(ex.getStackTrace());
			}
		}
	}

	public List<Noticia> listNoticia() {

		String sqlSelect = "SELECT * FROM noticia";

		List<Noticia> listaNoticia = new ArrayList<>();

		try (PreparedStatement preparedStatement = conect.prepareStatement(sqlSelect);) {

			ResultSet resultSet = preparedStatement.executeQuery();

			while (resultSet.next()) {
				Noticia noticia = new Noticia();
				noticia.setTitulo(resultSet.getString("titulo"));
				noticia.setDescricao(resultSet.getString("descricao"));
				noticia.setTexto(resultSet.getString("texto"));
				noticia.setId(resultSet.getInt("id"));
				listaNoticia.add(noticia);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return listaNoticia;
	}

	public void updateNoticia(Integer id, Noticia noticia) {

		String updateNoticia = "UPDATE noticia " + "SET titulo = ?, descricao = ?, texto = ? " + " WHERE id = ? ";

		try (PreparedStatement preparedStatement = conect.prepareStatement(updateNoticia)) {

			preparedStatement.setString(1, noticia.getTitulo());
			preparedStatement.setString(2, noticia.getDescricao());
			preparedStatement.setString(3, noticia.getTexto());
			preparedStatement.setInt(4, id);

			preparedStatement.execute();

		} catch (SQLException ex) {
			System.err.println("N�o foi possivel modificar" + "a tabela Noticia.");
			ex.printStackTrace();
		}
	}

	public void delete(Integer id) {

		String excluir = "DELETE FROM noticia " + " WHERE id = ? ";

		try (PreparedStatement pst = conect.prepareStatement(excluir)) {

			pst.setInt(1, id);
			pst.execute();

		} catch (SQLException ex) {
			System.err.println("N�o foi possivel excluir " + "a noticia");
			ex.printStackTrace();
		}
	}

}