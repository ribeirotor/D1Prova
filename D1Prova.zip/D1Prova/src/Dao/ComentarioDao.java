package Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import Bean.Comentario;
import ConnectionFactory.ConnectionFactory;

public class ComentarioDao {

	private Connection conect;

	public ComentarioDao() {
		new ConnectionFactory();
		this.conect = ConnectionFactory.conectar();
	}
	
	public void insert(Comentario comentario) {

		String insert = "INSERT INTO comentario (nome,texto, fk_noticia_id) " + "VALUES (?,?,?)";

		try (PreparedStatement preparedStatement = conect.prepareStatement(insert);) {

			preparedStatement.setString(1, comentario.getNome());
			preparedStatement.setString(2, comentario.getComentario());
			preparedStatement.setInt(3, comentario.getPk());
			preparedStatement.execute();
		} catch (Exception e) {
			e.printStackTrace();
			try {
				conect.rollback();
			} catch (SQLException ex) {
				System.out.println(ex.getStackTrace());
			}
		}
	}

	public List<Comentario> listComentario(Integer id) {

		String sqlSelect = "SELECT * FROM comentario WHERE fk_noticia_id = ?";

		List<Comentario> listaComentario = new ArrayList<>();

		try (PreparedStatement preparedStatement = conect.prepareStatement(sqlSelect);) {
			
			preparedStatement.setInt(1, id);
			ResultSet resultSet = preparedStatement.executeQuery();

			while (resultSet.next()) {
				Comentario comentarioModel = new Comentario();
				comentarioModel.setNome(resultSet.getString("nome"));
				comentarioModel.setComentario(resultSet.getString("texto"));
				listaComentario.add(comentarioModel);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return listaComentario;
	}
}